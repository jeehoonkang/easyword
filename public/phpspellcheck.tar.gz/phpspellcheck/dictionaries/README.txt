Installation of New Dictionaries:

1 - Dictionaries can be downloaded for free from www.phpspellcheck.com/download
2 - Unzip 
3 - Copy the .dic file to this folder (phpspellcheck/dictionaries/)

Adding New Words:
1 - Add 1 word per line to custom.txt

Removing Words:
1 - Add 1 word per line to language-rules/banned-words.txt


Happy Coding